/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import assm.Objects.Employee;
import java.util.List;

/**
 *
 * @author balis
 */
public interface EmployeeListInterface {

    public <T> void searchInList(T search);

    public List<Employee> returnEmpList();

    public List<Employee> returnSortList();

    public void setEmpList(Object newList);

    public Employee getEmp(int index);

    public void addEmp(Employee e);

    public void updateEmp(int index, Employee newEmp);

    public void removeEmp(int index);

    public int getEmpListSize();
}
