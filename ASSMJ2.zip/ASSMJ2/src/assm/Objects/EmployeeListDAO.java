/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assm.Objects;

import java.util.ArrayList;
import java.util.List;
import Interfaces.EmployeeListInterface;
import java.util.Comparator;
import java.util.LinkedList;

/**
 *
 * @author balis
 */
public class EmployeeListDAO implements EmployeeListInterface {

    private static List<Employee> empList = new ArrayList<Employee>();
    private static List<Employee> sortList = new LinkedList<Employee>();
    private Comparable<Employee> comparator;

    @Override
    public List<Employee> returnEmpList() {
        return empList;
    }

    @Override
    public List<Employee> returnSortList() {
        return sortList;
    }

    @Override
    public void setEmpList(Object newList) {
        empList = (ArrayList<Employee>) newList;
    }

    @Override
    public Employee getEmp(int index) {
        return empList.get(index);
    }

    @Override
    public void addEmp(Employee e) {
        empList.add(e);
    }

    @Override
    public void updateEmp(int index, Employee newEmp) {
        empList.set(index, newEmp);
    }

    @Override
    public void removeEmp(int index) {
        empList.remove(index);
    }

    @Override
    public int getEmpListSize() {
        return empList.size();
    }

    @Override
    public <T> void searchInList(T search) {
        sortList.clear();
        for (Employee e : empList) {
            if (e.toString().toLowerCase().contains(((String) search).toLowerCase())) {
                sortList.add(e);
            }
        }
    }

}
